README ADA3
1. Abrir el archivo .C, al ejecutarlo, se creará una carpeta llamada 'output'  contenida en la carpeta descargada, donde estará el archivo exe.
2. Insertar en la carpeta 'output' el archivo csv.
3. Compilar nuevamente el código y seleccionar probar las opciones del menú.