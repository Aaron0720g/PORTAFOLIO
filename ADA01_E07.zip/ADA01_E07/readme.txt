Para compilar el archivo se deben seguir los siguientes pasos:
1.-descomprimir la carpeta
2.-compilar el archivo InfijoAPostfijoApp.cpp, esto generara un archivo InfijoAPostfijoApp.exe en la misma carpeta
3.-abrir el cmd y escribir el comando cd y la dirección de la carpeta; ejemplo: cd C:\Users\Aaron\Desktop\c++\Escuela\Estructura de datos\ADAS
4.-escribir el comando InfijoAPostfijoApp.exe exp_infijas.txt en el cmd

esto generara un archivo en la misma carpeta llamado exp_postfijas.txt y en el se mostraran los resultados de las operaciones aritméticas y las expresiones postfijas.
